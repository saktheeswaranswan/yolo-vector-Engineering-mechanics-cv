class,x,y,width,height,vector_x,vector_y
car,100,150,50,50,30,-20
bike,200,300,40,40,-10,40

